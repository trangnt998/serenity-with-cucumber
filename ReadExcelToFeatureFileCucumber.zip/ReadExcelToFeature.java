package Excel;

import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.FormulaEvaluator;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.*;
import java.util.ArrayList;
import java.util.Arrays;

public class ReadExcelToFeature { //read excel to feature file in cucumber
    public static File input;
    final ArrayList<String> Frimary = new ArrayList<>(Arrays.asList("Feature:","Rule","Background", "Scenario Outline:", "Scenario Template:", "Scenario:","@")); //ki tu "|" se hieu la bat dau 1 data table, chi viet duy nhat 1 ki tu nay truoc data table, trong cell dau tien cua row chua data table
    final ArrayList<String> Secondary = new ArrayList<>(Arrays.asList("Examples:","Given", "When", "Then", "And", "But", "*", "|")); //ki tu "|" se hieu la bat dau 1 data table, chi viet duy nhat 1 ki tu nay truoc data table, trong cell dau tien cua row chua data table
    final ArrayList<String> High = new ArrayList<>(Arrays.asList("*", "|")); //ki tu "|" se hieu la bat dau 1 data table, chi viet duy nhat 1 ki tu nay truoc data table, trong cell dau tien cua row chua data table

    public ReadExcelToFeature(String inputFile) {
        input = new File(inputFile);
    }

    public void Run(String inputFile, String outputFile) throws IOException {
        ReadExcelToFeature RA = new ReadExcelToFeature(inputFile);
        System.out.println("Input File: "+RA.input);
        System.out.println("========================");
        FileInputStream finput = new FileInputStream(RA.input);
        XSSFWorkbook workbook = new XSSFWorkbook(finput);

        for (int i = 0; i < workbook.getNumberOfSheets(); i++) {

            XSSFSheet sheet = workbook.getSheetAt(i); //read all sheets of file excel
            BufferedWriter myWrite = new BufferedWriter(new FileWriter(outputFile + workbook.getSheetName(i) + ".feature"));
            System.out.println("Output File "+(i+1)+": "+ outputFile + workbook.getSheetName(i) + ".feature");
            myWrite.write("Feature: " + workbook.getSheetName(i)); //noi dung feature la ten sheet

            XSSFCell Cell;
            XSSFRow Row;

            int countRow = sheet.getLastRowNum() + 1; //dem tong so hang cua sheet
            int rowIndex = 0; //chi so hang

            while (rowIndex < countRow) {//doc het dong trong sheet
                String checkDataTable = null;

                myWrite.write("\n"); //xuong dong theo kich ban
                int cols = 0; //dem cot
                int tmp;

                Row = sheet.getRow(rowIndex);
                //if Row is null thi bo qua dong

                if(Row != null){
                    tmp = Row.getLastCellNum(); //tim cot cho cell
                    if (cols < tmp)
                        cols = tmp;

                    for (int c = 0; c < cols; c++) { //lay Cell
                        Cell = Row.getCell(c);

                        if(Cell == null){
                            if(checkDataTable == "|")
                                myWrite.write("|");
                            else
                                myWrite.write("");
                        }

                        if(Cell != null){
                            if(Cell.getColumnIndex() == 0 && Cell.getStringCellValue().equals("|"))//check datatable or example
                                checkDataTable ="|";


                            switch (Cell.getCellType()){
                                case STRING:
                                    if(Frimary.contains(Cell.getStringCellValue()))
                                        myWrite.write("  ");
                                    if(Secondary.contains(Cell.getStringCellValue()))
                                        myWrite.write("  "+"  ");
                                    if (High.contains(Cell.getStringCellValue()))
                                        myWrite.write("  ");

                                    if (checkDataTable == "|" && Cell.getColumnIndex() != 0)
                                        myWrite.write(Cell.getStringCellValue() + "|"); //ghi datatable va example
                                    else if(checkDataTable =="|" && Cell.getColumnIndex() == 0)
                                        myWrite.write(Cell.getStringCellValue());
                                    else
                                        myWrite.write(Cell.getStringCellValue() + " "); //ghi cac doan kich ban khong phai dang datatable va example, tu dong chen them dau cach
                                    break;


                                case NUMERIC:    //field that represents number cell type
                                    if (checkDataTable == "|" && Cell.getColumnIndex() != 0) { //truong hop datatable va example
                                        if ((Cell.getNumericCellValue() % 1 == 0)) //so nguyen
                                            myWrite.write((int) Cell.getNumericCellValue() + "|");
                                        else //so dang thap phan
                                            myWrite.write(Cell.getNumericCellValue() + "|");
                                    } else {
                                        if ((Cell.getNumericCellValue() % 1 == 0)) //so nguyen
                                            myWrite.write((int) Cell.getNumericCellValue() + " ");
                                        else
                                            myWrite.write(Cell.getNumericCellValue() + " ");
                                    }
                                    break;


                                case FORMULA:    //field that represents formula cell type
                                    FormulaEvaluator evaluator = workbook.getCreationHelper().createFormulaEvaluator();
                                    if (checkDataTable == "|" && Cell.getColumnIndex() != 0) { //truong hop datatable
                                        if (evaluator.evaluate(Cell).getCellType() == CellType.NUMERIC) {
                                            if ((evaluator.evaluate(Cell).getNumberValue() % 1) == 0) //neu so int thi khong lay dang .0 (vi du: 1.0 thi lay 1)
                                                myWrite.write((int) evaluator.evaluate(Cell).getNumberValue() + "|");

                                            else
                                                myWrite.write((float) evaluator.evaluate(Cell).getNumberValue() + "|");
                                        } else
                                            myWrite.write(evaluator.evaluate(Cell).getStringValue() + "|");
                                    } else { //truong hop ko phai datatable
                                        if (evaluator.evaluate(Cell).getCellType() == CellType.NUMERIC) {
                                            if ((evaluator.evaluate(Cell).getNumberValue() % 1) == 0)
                                                myWrite.write((int) evaluator.evaluate(Cell).getNumberValue() + " ");
                                            else
                                                myWrite.write((float) evaluator.evaluate(Cell).getNumberValue() + " ");
                                        } else
                                            myWrite.write(evaluator.evaluate(Cell).getStringValue() + " ");
                                    }
                                    break;


                                case BOOLEAN:
                                    if (checkDataTable == "|" && Cell.getColumnIndex() != 0)
                                        myWrite.write(Cell.getBooleanCellValue() + "|"); //ghi datatable va example
                                    else
                                        myWrite.write(Cell.getBooleanCellValue() + " "); //ghi cac doan kich ban khong phai dang datatable va example, tu dong chen them dau cach
                                    break;


                                case _NONE:
                                    break;

                                case BLANK:
                                    break;

                                case ERROR:
                                    break;

                                default:
                            }
                        }
                    }
                }
                rowIndex++;
            }
            myWrite.close();
        }
    }
}
