package Excel;

import java.io.IOException;

public class RunReadExcelToFeature {
    public static void main(String[] args) throws IOException {

        String inputFile = "src/test/resources/data/KBKT_seleniumeasy.com.xlsx";
        String outputFile = "src/test/resources/features/";

        ReadExcelToFeature run = new ReadExcelToFeature(inputFile);

        run.Run(inputFile, outputFile);
    }
}
